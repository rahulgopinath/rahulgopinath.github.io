

"""
simpleinvariantminer.

Invariant Miner
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2026/05/09/simple-invariant-miner/'

from .post import *
