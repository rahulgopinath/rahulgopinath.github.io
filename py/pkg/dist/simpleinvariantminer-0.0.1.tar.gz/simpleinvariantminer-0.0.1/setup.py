
from setuptools import setup

setup(
    name='simpleinvariantminer',
    version='0.0.1',
    description='Invariant Miner',
    url='https://rahul.gopinath.org/post/2026/05/09/simple-invariant-miner/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['simpleinvariantminer'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
