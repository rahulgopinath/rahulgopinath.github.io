
from setuptools import setup

setup(
    name='gnegatedfaults',
    version='0.0.1',
    description='Specializing Context-Free Grammars for Not Inducing A Fault',
    url='https://rahul.gopinath.org/post/2021/09/12/negated-fault-grammars/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['gnegatedfaults'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
