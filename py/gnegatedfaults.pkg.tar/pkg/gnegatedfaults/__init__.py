

"""
gnegatedfaults.

Specializing Context-Free Grammars for Not Inducing A Fault
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/09/12/negated-fault-grammars/'

from .post import *
