
from setuptools import setup

setup(
    name='rxfuzzer',
    version='0.0.1',
    description='iFuzzing With Regular Expressions',
    url='https://rahul.gopinath.org/post/2021/10/22/fuzzing-with-regular-expressions/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['rxfuzzer'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
