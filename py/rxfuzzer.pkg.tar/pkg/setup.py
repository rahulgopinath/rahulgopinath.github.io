from setuptools import setup

setup(
    name='rxfuzzer',
    version='0.0.1',    
    description='Fuzzing With Regular Expressions',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/021-10-22-fuzzing-with-regular-expressions.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['rxfuzzer'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

