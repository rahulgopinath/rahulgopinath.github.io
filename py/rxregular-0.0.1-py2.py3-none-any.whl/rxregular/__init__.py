"""
RXRegular.

Regular Expression to Regular Grammar
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'


from .post import *
