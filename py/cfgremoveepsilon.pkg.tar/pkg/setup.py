from setuptools import setup

setup(
    name='cfgremoveepsilon',
    version='0.0.1',    
    description='Remove Empty (Epsilon) Rules From a Context-Free Grammar.',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2021-09-29-remove-epsilons.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['cfgremoveepsilon'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

