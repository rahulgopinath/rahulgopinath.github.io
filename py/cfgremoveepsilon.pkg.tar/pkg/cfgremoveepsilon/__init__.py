

"""
cfgremoveepsilon.

Remove Empty (Epsilon) Rules From a Context-Free Grammar.
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/09/29/remove-epsilons/'

from .post import *
