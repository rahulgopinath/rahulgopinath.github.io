"""
CFGRemoveEpsilon.

Remove Empty (Epsilon) Rules From a Context-Free Grammar.
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'


from .post import *
