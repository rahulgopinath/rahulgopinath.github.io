"""
simplefuzzer.

A simple grammar fuzzer.
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2019-05-28-simplefuzzer-01.py'


from post import *
