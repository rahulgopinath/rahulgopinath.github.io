
from setuptools import setup

setup(
    name='simplefuzzer',
    version='0.0.1',
    description='The simplest grammar fuzzer in the world',
    url='https://rahul.gopinath.org/post/2019/05/28/simplefuzzer-01/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['simplefuzzer'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
