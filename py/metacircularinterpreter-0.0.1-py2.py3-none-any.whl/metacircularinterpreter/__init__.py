

"""
metacircularinterpreter.

Python Meta Circular Interpreter
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2019/12/07/python-mci/'

from .post import *
