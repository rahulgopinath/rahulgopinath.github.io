from setuptools import setup

setup(
    name='gfaultexpressions',
    version='0.0.1',    
    description='Fault Expressions for Specializing Context-Free Grammars',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2021-09-11-fault-expressions.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['gfaultexpressions'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

