
from setuptools import setup

setup(
    name='gfaultexpressions',
    version='0.0.1',
    description='Fault Expressions for Specializing Context-Free Grammars',
    url='https://rahul.gopinath.org/post/2021/09/11/fault-expressions/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['gfaultexpressions'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
