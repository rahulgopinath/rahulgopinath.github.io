

"""
rxregular.

Regular Expression to Regular Grammar
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/10/23/regular-expression-to-regular-grammar/'

from .post import *
