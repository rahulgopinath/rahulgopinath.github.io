

"""
pegparser.

Recursive descent parsing with Parsing Expression (PEG) and Context Free (CFG) Grammars
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2018/09/06/peg-parsing/'

from .post import *
