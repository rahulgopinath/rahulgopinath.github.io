

"""
hdd.

Hierarchical Delta Debugging
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2019/12/04/hdd/'

from .post import *
