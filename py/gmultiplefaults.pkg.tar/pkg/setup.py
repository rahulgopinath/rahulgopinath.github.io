
from setuptools import setup

setup(
    name='gmultiplefaults',
    version='0.0.1',
    description='Specializing Context-Free Grammars for Inducing Multiple Faults',
    url='https://rahul.gopinath.org/post/2021/09/10/multiple-fault-grammars/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['gmultiplefaults'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
