from setuptools import setup

setup(
    name='gmultiplefaults',
    version='0.0.1',    
    description='Specializing Context-Free Grammars for Inducing Multiple Faults',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2021-09-10-multiple-fault-grammars.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['gmultiplefaults'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

