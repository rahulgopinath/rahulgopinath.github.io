"""
MetaCircularInterpreter.

Python Meta Circular Interpreter
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'


from .post import *
