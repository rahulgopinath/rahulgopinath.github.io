

"""
lstar.

L* Algorithm
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2024/01/04/lstar-learning-regular-languages/'

from .post import *
