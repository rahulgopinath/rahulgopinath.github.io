

"""
rpni.

RPNI Algorithm
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2025/10/24/rpni-learning-regular-languages/'

from .post import *
