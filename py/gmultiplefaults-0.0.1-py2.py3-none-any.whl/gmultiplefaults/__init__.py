

"""
gmultiplefaults.

Specializing Context-Free Grammars for Inducing Multiple Faults
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/09/10/multiple-fault-grammars/'

from .post import *
