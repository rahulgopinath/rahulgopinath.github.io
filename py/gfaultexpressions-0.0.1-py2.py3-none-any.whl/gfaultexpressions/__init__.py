"""
GFaultExpressions.

Fault Expressions for Specializing Context-Free Grammars
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'


from .post import *
