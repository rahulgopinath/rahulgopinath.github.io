

"""
rxexpressions.

Conjunction, Disjunction, and Complement of Regular Grammars
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/10/26/regular-grammar-expressions/'

from .post import *
