
from setuptools import setup

setup(
    name='rxexpressions',
    version='0.0.1',
    description='Conjunction, Disjunction, and Complement of Regular Grammars',
    url='https://rahul.gopinath.org/post/2021/10/26/regular-grammar-expressions/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['rxexpressions'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
