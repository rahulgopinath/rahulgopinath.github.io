
from setuptools import setup

setup(
    name='gllparser',
    version='0.0.1',
    description='GLL Parser',
    url='https://rahul.gopinath.org/post/2022/07/02/generalized-ll-parser/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['gllparser'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
