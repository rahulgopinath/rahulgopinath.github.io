
from setuptools import setup

setup(
    name='lrparser',
    version='0.0.1',
    description='LR Parser',
    url='https://rahul.gopinath.org/post/2024/07/01/lr-parsing/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['lrparser'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
