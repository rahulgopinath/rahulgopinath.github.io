

"""
rxfuzzer.

iFuzzing With Regular Expressions
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/10/22/fuzzing-with-regular-expressions/'

from .post import *
