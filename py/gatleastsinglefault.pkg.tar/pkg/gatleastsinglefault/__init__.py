

"""
gatleastsinglefault.

Specializing Context-Free Grammars for Inducing Faults
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2021/09/09/fault-inducing-grammar/'

from .post import *
