from setuptools import setup

setup(
    name='gatleastsinglefault',
    version='0.0.1',    
    description='Specializing Context-Free Grammars for Inducing Faults',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2020-08-03-simple-ddset.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['gatleastsinglefault'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

