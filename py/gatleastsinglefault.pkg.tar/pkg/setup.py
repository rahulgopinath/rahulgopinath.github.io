
from setuptools import setup

setup(
    name='gatleastsinglefault',
    version='0.0.1',
    description='Specializing Context-Free Grammars for Inducing Faults',
    url='https://rahul.gopinath.org/post/2021/09/09/fault-inducing-grammar/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['gatleastsinglefault'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
