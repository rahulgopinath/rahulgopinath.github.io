"""
CFGRandomSample.

Uniform Random Sampling of Strings from Context-Free Grammar
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'


from .post import *
