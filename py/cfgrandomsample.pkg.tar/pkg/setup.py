from setuptools import setup

setup(
    name='cfgrandomsample',
    version='0.0.1',    
    description='Uniform Random Sampling of Strings from Context-Free Grammar',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2021-07-27-random-sampling-from-context-free-grammar.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['cfgrandomsample'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

