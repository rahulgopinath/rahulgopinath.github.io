
from setuptools import setup

setup(
    name='cfgrandomsample',
    version='0.0.1',
    description='Uniform Random Sampling of Strings from Context-Free Grammar',
    url='https://rahul.gopinath.org/post/2021/07/27/random-sampling-from-context-free-grammar/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['cfgrandomsample'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
