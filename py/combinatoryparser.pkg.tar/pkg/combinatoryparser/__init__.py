

"""
combinatoryparser.

Simple Combinatory Parsing For Context Free Languages
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2020/03/02/combinatory-parsing/'

from .post import *
