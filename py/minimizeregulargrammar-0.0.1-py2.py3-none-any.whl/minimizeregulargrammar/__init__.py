

"""
minimizeregulargrammar.

Minimize Regular Grammar
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2023/11/02/minimizing-canonical-regular-grammar-dfa/'

from .post import *
