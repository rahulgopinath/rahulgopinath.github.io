

"""
removeleftrecursion.

Remove Left Recursion
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2023/10/19/remove-left-recursion/'

from .post import *
