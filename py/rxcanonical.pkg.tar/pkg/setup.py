
from setuptools import setup

setup(
    name='rxcanonical',
    version='0.0.1',
    description='Converting a Regular Expression to DFA using Regular Grammar',
    url='https://rahul.gopinath.org/post/2021/10/24/canonical-regular-grammar/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['rxcanonical'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
