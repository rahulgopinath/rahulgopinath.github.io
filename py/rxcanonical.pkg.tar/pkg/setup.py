from setuptools import setup

setup(
    name='rxcanonical',
    version='0.0.1',    
    description='Converting a Regular Expression to DFA using Regular Grammar',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2021-10-24-canonical-regular-grammar.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['rxcanonical'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

