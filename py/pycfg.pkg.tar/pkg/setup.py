
from setuptools import setup

setup(
    name='pycfg',
    version='0.0.1',
    description='The Python Control Flow Graph',
    url='https://rahul.gopinath.org/post/2019/12/08/python-controlflow/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['pycfg'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
