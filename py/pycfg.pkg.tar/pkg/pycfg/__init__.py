

"""
pycfg.

The Python Control Flow Graph
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2019/12/08/python-controlflow/'

from .post import *
