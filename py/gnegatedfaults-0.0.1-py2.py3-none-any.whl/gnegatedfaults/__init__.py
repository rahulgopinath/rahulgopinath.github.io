"""
GNegatedFaults.

Specializing Context-Free Grammars for Not Inducing A Fault
"""

__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'


from .post import *
