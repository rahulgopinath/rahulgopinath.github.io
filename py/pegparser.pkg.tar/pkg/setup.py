
from setuptools import setup

setup(
    name='pegparser',
    version='0.0.1',
    description='Recursive descent parsing with Parsing Expression (PEG) and Context Free (CFG) Grammars',
    url='https://rahul.gopinath.org/post/2018/09/06/peg-parsing/',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzzingbook',
    packages=['pegparser'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)
