from setuptools import setup

setup(
    name='ddset',
    version='0.0.1',    
    description='DDSet',
    url='https://github.com/rahulgopinath/rahulgopinath.github.io/blob/master/notebooks/2020-08-03-simple-ddset.py',
    author='Rahul Gopinath',
    author_email='rahul@gopinath.org',
    license='Fuzingbook',
    packages=['ddset'],
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
    ],
)

