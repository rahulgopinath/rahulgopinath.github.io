

"""
ddset.

Simple DDSet
"""
__version__ = '0.0.1'
__author__ = 'Rahul Gopinath'
__url__ = 'https://rahul.gopinath.org/post/2020/08/03/simple-ddset/'

from .post import *
