package com.sun.servlet;

import java.io.*;
import java.util.*;
import java.util.regex.*;

import javax.servlet.*;
import javax.servlet.http.*;


import javax.script.*;


public class JSR223Servlet extends ScriptServlet {

    private static Pattern FILENAME = Pattern.compile("^(.*).([^.]+)$");
    protected ScriptEngineManager _sem = new ScriptEngineManager();
    protected ScriptEngine _eng = null;

    protected ScriptEngine getScriptEngine(String filename)
        throws Exception {
        // see if the user has some preference?
        String lang = getServletConfig().getInitParameter("language");
        if (lang != null) {
            ScriptEngine se = _sem.getEngineByName(lang);
            if (se!= null)
                return se;
        }

        // or figure out the engine to use by extension.
        Matcher m = FILENAME.matcher(filename);
        if (m.matches()) {
            String ext = m.group(1);
            ScriptEngine se = _sem.getEngineByExtension(ext);
            if (se != null)
                return se;
        }

        // we failed miserably. :(
        throw new Exception("Unable to figure out a script engine to use.");
    }

    public void initialize(String handler, Object code)
        throws Exception {
        List<ScriptEngineFactory> list = _sem.getEngineFactories(); // seems needed for init.
        _eng = getScriptEngine(handler);
        // we want to bind the variable httpservlet for initialization rather than
        // call a method.
        _eng.getContext().setAttribute("httpservlet", this, ScriptContext.ENGINE_SCOPE);
        _eng.eval((String)code);
    }

    public void eval(Object fn, HttpServletRequest request, HttpServletResponse response) {
        try {
            if (_eng instanceof Invocable) {
                Invocable inv = (Invocable)_eng;
                inv.invokeFunction((String)fn, this, request, response);
            } else {
                _eng.getContext().setAttribute("httpservlet", this, ScriptContext.ENGINE_SCOPE);
                _eng.getContext().setAttribute("request", request, ScriptContext.ENGINE_SCOPE);
                _eng.getContext().setAttribute("response", response, ScriptContext.ENGINE_SCOPE);
                _eng.eval((String)fn);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void printEngines() {
        List<ScriptEngineFactory> list = _sem.getEngineFactories();
        System.out.println("Supported Script Engines");
        for (ScriptEngineFactory factory: list) {
            // Obtains the full name of the ScriptEngine.
            String name = factory.getEngineName();
            String version = factory.getEngineVersion();
            // Returns the name of the scripting language
            // supported by this ScriptEngine
            String language = factory.getLanguageName();
            String languageVersion = factory.getLanguageVersion();
            System.out.printf("Name: %s (%s) : Language: %s v. %s \n",
                    name, version, language, languageVersion);
            // Get a list of aliases
            List<String> engNames = factory.getNames();
            for(String e: engNames) {
                System.out.printf("\tEngine Alias: %s\n", e);
            }
        }
    }

}
