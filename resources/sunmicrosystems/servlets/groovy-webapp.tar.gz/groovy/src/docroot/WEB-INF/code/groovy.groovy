def do_service (httpservlet, request, response) {
    out = response.getWriter()
    response.setContentType("text/html")
    try {
        spath = request.getServletPath()
        filename = httpservlet.getServletConfig().getServletContext().getRealPath(spath)
        GroovyShell shell = new GroovyShell()   
        shell.setVariable("request", request);
        shell.setVariable("response", response);
        shell.setVariable("httpservlet", httpservlet);
        out.println shell.evaluate(httpservlet.read(filename).toString(), filename)
    } catch (e) {
        out.println "<html><body><b>Servlet Error ( "+ e.getMessage() + "</b><xmp> " 
        e.printStackTrace(out);
        out.println " </xmp></body></html>"
    }
}

httpservlet.add('get', "do_service")
httpservlet.add('post', "do_service")

