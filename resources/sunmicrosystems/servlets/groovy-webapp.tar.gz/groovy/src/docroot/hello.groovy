pre = "<html> <head><title>abc</title></head> <body> <h1> Hello at "
date = new Date()
from = " from "
path = request.getServletPath()
post = "</h1>  </body> </html>"
pre + date + from + path + post
