package com.sun.servlet;

import javax.servlet.http.*;
import jscheme.*;

public class SchemeServlet extends ScriptServlet {

    public static JScheme js = new JScheme();

    public void initialize(String handler, Object code)
        throws Exception {
        js.apply((jsint.Procedure)js.eval((String)code),js.list(this));
    }

    public void eval(Object fn, HttpServletRequest request, HttpServletResponse response) {
        if (request == null)
            js.apply((jsint.Procedure)fn, js.list());
        else
            js.apply((jsint.Procedure)fn, js.list(request, response));
    }
}
