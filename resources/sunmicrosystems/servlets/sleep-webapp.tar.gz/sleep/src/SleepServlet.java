package com.sun.servlet;

import javax.servlet.http.*;
import java.util.*;
import sleep.interfaces.Evaluation;
import sleep.runtime.*;
import sleep.engine.*;
import sleep.bridges.*;
import sleep.error.*;

public class SleepServlet extends ScriptServlet {

    ScriptLoader loader = new ScriptLoader();
    ScriptInstance js = null;

    public StringBuffer err = new StringBuffer();

    public void initialize(String handler, Object code) throws Exception {
        js = loader.loadScript(handler, (String)code, new Hashtable());
        js.addWarningWatcher(new RuntimeWarningWatcher() {
            public void processScriptWarning(ScriptWarning w) {
                String message = w.getMessage();
                int lineNo  = w.getLineNumber();
                String script = w.getNameShort();
                err.append(message + " at " + script + ":" + lineNo + "\n");
            }
        });

        Block blk = js.getRunnableBlock();
        SleepClosure sc = new SleepClosure(js, blk);

        Stack stk = new Stack();
        stk.push(SleepUtils.getScalar(this));
        sc.callClosure("&main", js, stk);
    }

    public void eval(Object fn, HttpServletRequest request, HttpServletResponse response) {
        Stack stk = new Stack();
        stk.push(SleepUtils.getScalar(response));
        stk.push(SleepUtils.getScalar(request));
        ((SleepClosure)fn).callClosure("&closure", js, stk);
    }
}
