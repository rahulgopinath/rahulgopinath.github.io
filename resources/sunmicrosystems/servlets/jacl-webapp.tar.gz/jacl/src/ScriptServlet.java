package com.sun.servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public abstract class ScriptServlet extends GenericServlet {

    private HashMap<String, Object> _sym = new HashMap<String, Object>();

    public HashMap sym() {
        return _sym;
    }

    public void add(String sym, Object fn) {
        _sym.put(sym.toLowerCase(), fn);
    }

    public void init() throws ServletException {
        ServletConfig config = getServletConfig();
        if (config == null) return;
        try {
            String handler = config.getInitParameter("handler");
            if (handler != null) {
                ServletContext sc = config.getServletContext();
                InputStream stream = sc.getResourceAsStream(handler);
                initialize(handler, read(stream));
                stream.close();
            } else
                System.out.println("No handler");
        } catch (Exception e) {
            System.out.println("During ScriptServlet.init(): ");
            e.printStackTrace();
        }
    }

    public abstract void initialize(String handler, Object code) throws Exception;

    public abstract void eval(Object fn, HttpServletRequest request, HttpServletResponse response);

    public void service(ServletRequest request,  ServletResponse response) 
        throws IOException, ServletException {
        service((HttpServletRequest)request, (HttpServletResponse)response);
    }

    public void service(HttpServletRequest request,  HttpServletResponse response)
        throws IOException, ServletException {
        // do we have the named method?
        if (sym().containsKey(request.getMethod().toLowerCase()))
            eval(sym().get(request.getMethod().toLowerCase()), request, response);
        // or are we atleast overriding the service?
        if (sym().containsKey("service")) {
            eval(sym().get("service"), request, response);
            response.setStatus(200);
        } //else
        //// super.service(request, response);
    }

    public void destroy() {
        if (sym().containsKey("destroy"))
            eval(sym().get("destroy"), null, null);
        else
            super.destroy();
    }

    // Library functions that may be faster(performance) to do in java
    // than in our client languages.

    private static Hashtable<String, Object> _cache = new Hashtable<String, Object>();
    public static Hashtable<String, Object> cache() {
        return _cache;
    }
    // read all in a file and return.
    // If required, the client program can override this method to supply compiled
    // code
    public Object read(String name)
        throws IOException {
        if (_cache.containsKey(name))
            return (String)_cache.get(name);
        Object val = read(new FileInputStream(name));
        _cache.put(name, val);
        return val;
    }

    public Object read(InputStream in)
        throws IOException {
        StringBuffer sb = new StringBuffer();
        String line = null;
        DataInputStream ds = new DataInputStream(in);
        while ((line = ds.readLine()) != null) {
            sb.append(line);
            sb.append("\n");
        }
        return sb.toString();
    }
}
