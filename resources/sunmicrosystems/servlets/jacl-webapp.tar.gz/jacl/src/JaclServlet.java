package com.sun.servlet;

import java.io.*;
import java.util.*;
import tcl.lang.*;

import javax.servlet.http.*;

public class JaclServlet extends ScriptServlet {

    public static Interp jt = new Interp();

    public void initialize(String handler, Object code) throws Exception {
        jt.setVar("httpservlet",ReflectObject.newInstance(jt, JaclServlet.class, this), TCL.GLOBAL_ONLY);
        jt.eval((String)code);
    }

    public void eval(Object fn, HttpServletRequest request, HttpServletResponse response) {
        try {
            jt.setVar("request",ReflectObject.newInstance(jt, HttpServletRequest.class, request), TCL.NAMESPACE_ONLY);
            jt.setVar("response",ReflectObject.newInstance(jt, HttpServletResponse.class, response), TCL.NAMESPACE_ONLY);
            jt.eval((String)fn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
