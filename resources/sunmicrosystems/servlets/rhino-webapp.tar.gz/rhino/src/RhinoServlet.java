package com.sun.servlet;

import javax.servlet.http.*;
import org.mozilla.javascript.*;
import org.mozilla.javascript.tools.shell.Global;

public class RhinoServlet extends ScriptServlet {
    public Context jm = Context.enter();
    protected final Global global = new Global();

    protected void finalize() throws Throwable {
        Context.exit();
    }

    public void initialize(String handler, Object code) throws Exception {
        global.init(jm);
        Function funct = jm.compileFunction(global, (String)code, handler, 1, null);
        funct.call(jm, global, funct, new Object[] {jm.javaToJS(this, global)});
    }

    public void eval(Object fn, HttpServletRequest request, HttpServletResponse response) {
        ((Function)fn).call(jm, global, (Function)fn, new Object[] {
            jm.javaToJS(request, global), 
            jm.javaToJS(response, global)});
    }
}
