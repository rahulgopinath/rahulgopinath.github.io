function (httpservlet) {
    do_get = function (request,response) {
        response.setContentType("text/html");
        this.out = response.getWriter();

        this.request = request;
        this.response = response;
        this.httpservlet = httpservlet;

        try {
            spath = request.getServletPath();
            filename = httpservlet.getServletConfig().getServletContext().getRealPath(spath);
            body = httpservlet.read(filename) + ""; // convert body to javascript string.
            this.out.println(eval(body));
        } catch (e) {
            this.out.println("<html><body><b>Servlet Error ("
                    + e.name + ")</b><xmp>" + e.message + "</xmp></body></html>");
        }
    }
    httpservlet.add('get', do_get);
    httpservlet.add('post', do_get);
}
